from exercise_code.networks.fc_net import *
